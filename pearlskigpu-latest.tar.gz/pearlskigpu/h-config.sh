#!/usr/bin/env bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

if [[ -z "$MINER_DIR" || -z "$CUSTOM_MINER" ]]; then
    MINER_PATH="$SCRIPT_DIR"
else
    MINER_PATH="$MINER_DIR/$CUSTOM_MINER"
fi

. "$MINER_PATH/h-manifest.conf"

download_update_stdout() {
    local url="$1"

    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --connect-timeout 10 --retry 2 "$url" 2>/dev/null
    elif command -v wget >/dev/null 2>&1; then
        wget -q -O - "$url" 2>/dev/null
    else
        return 1
    fi
}

normalize_update_hash() {
    awk 'NF {print $1; exit}' | tr -d '\r' | tr '[:upper:]' '[:lower:]'
}

schedule_hive_restart() {
    [[ "${PEARLSKI_UPDATE_RESTART:-1}" == "0" ]] && return 0

    if command -v screen >/dev/null 2>&1 && command -v miner >/dev/null 2>&1; then
        screen -d -m miner restart
    elif command -v miner >/dev/null 2>&1; then
        (sleep 1; miner restart) >/dev/null 2>&1 &
    else
        echo "Auto-update: miner restart command not available"
    fi
}

check_auto_update() {
    local remote_hash local_hash local_file

    [[ "${PEARLSKI_AUTO_UPDATE:-1}" == "0" ]] && return 0

    remote_hash=$(download_update_stdout "$PEARLSKI_UPDATE_HASH_URL" | normalize_update_hash)
    if [[ ! "$remote_hash" =~ ^[0-9a-f]{64}$ ]]; then
        echo "Auto-update skipped: no valid hash at $PEARLSKI_UPDATE_HASH_URL"
        return 0
    fi

    local_file="${PEARLSKI_UPDATE_LOCAL_FILE:-/hive/miners/custom/downloads/$PEARLSKI_UPDATE_ARCHIVE}"
    if [[ ! -f "$local_file" ]]; then
        echo "Auto-update skipped: local HiveOS archive cache not found: $local_file"
        return 0
    fi

    local_hash=$(sha256sum "$local_file" 2>/dev/null | awk '{print $1}' | tr '[:upper:]' '[:lower:]')
    if [[ "$local_hash" == "$remote_hash" ]]; then
        return 0
    fi

    echo "Auto-update: cached archive differs from remote, clearing $local_file"
    rm -f "$local_file"
    echo "Auto-update: requesting HiveOS miner restart"
    schedule_hive_restart
}

check_auto_update

TEMPLATE=$(echo "$CUSTOM_TEMPLATE" | awk '{print $1}')
WALLET="$TEMPLATE"
TEMPLATE_WORKER=""

if [[ "$TEMPLATE" == *.* ]]; then
    WALLET="${TEMPLATE%%.*}"
    TEMPLATE_WORKER="${TEMPLATE#*.}"
fi

if [[ -z "$WALLET" ]]; then
    echo -e "${RED}No wallet address configured${NOCOLOR}"
    exit 1
fi

MINER_ARGS="--user $WALLET"

if [[ -n "$TEMPLATE_WORKER" ]]; then
    MINER_ARGS="$MINER_ARGS --worker $TEMPLATE_WORKER"
elif [[ -n "$WORKER_NAME" ]]; then
    MINER_ARGS="$MINER_ARGS --worker $WORKER_NAME"
else
    MINER_ARGS="$MINER_ARGS --worker $(hostname)"
fi

if [[ "$CUSTOM_USER_CONFIG" != *"--gpus"* ]]; then
    MINER_ARGS="$MINER_ARGS --gpus auto"
fi

if [[ -n "$CUSTOM_USER_CONFIG" ]]; then
    MINER_ARGS="$MINER_ARGS $CUSTOM_USER_CONFIG"
fi

echo "$MINER_ARGS" > "$MINER_PATH/miner_args.txt"

echo "Pool mode: pearlski.jetskipool.ai:6969"
echo "Miner arguments: $MINER_ARGS"
